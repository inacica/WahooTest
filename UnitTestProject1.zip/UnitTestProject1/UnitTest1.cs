﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;

namespace WahooFitnessTests
{
    /// <summary>
    /// Summary description for WahooFitnessTests
    /// </summary>
    [TestClass]
    public class WahooTests
    {
        private TestContext testContextInstance;
        private IWebDriver driver;
        private string appURL;

        public WahooTests()
        {
        }

        [TestMethod]
        [TestCategory("Chrome")]
        public void OpenWahooTest()
        {
            driver.Navigate().GoToUrl(appURL + "/");
            driver.FindElement(By.XPath("//a[@href='/devices']")).Click();
            Thread.Sleep(1500);
            driver.FindElement(By.XPath("//a[@href ='https://eu.wahoofitness.com/devices/bike-trainers/kickr/buy']")).Click();
            driver.FindElement(By.XPath("//button[contains(@class, 'button tocart btn-cart')]")).Click();
            Thread.Sleep(5000);

            if (driver.FindElement(By.XPath("//div[contains(@class, 'minicart-offscreen-title')]")) != null)
            { Console.WriteLine("Minicart is present");}
            else { Console.WriteLine("Minicart is absent"); }
        }



        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        [TestInitialize()]
        public void SetupTest()
        {
            appURL = "https://eu.wahoofitness.com/";
            driver = new ChromeDriver();
        }

        [TestCleanup()]
        public void TestCleanup()
        {
            driver.Quit();
        }
    }
}
